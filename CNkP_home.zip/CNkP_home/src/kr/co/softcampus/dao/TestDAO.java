package kr.co.softcampus.dao;

import org.springframework.stereotype.Repository;

@Repository
public class TestDAO {
	
	public String testDaoMethod() {
		return "문자열";
	}
}
