/**
 * 
 */

/*var mapContainer = document.getElementById('map'), // 지도를 표시할 div
mapOption = {
	center : new kakao.maps.LatLng(37.564214, 127.001699), // 지도의 중심좌표
	level : 8
};
var map = new kakao.maps.Map(mapContainer, mapOption);
*/